import { useState } from "react";
import { ArrowLeft, Plus, X, Briefcase } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { PreferenceSlider } from "./PreferenceSlider";
import type { SignupData } from "./SignupForm";

interface ProfileSetupProps {
  signupData: SignupData;
  onComplete: (profileData: ProfileData) => void;
  onBack: () => void;
}

export interface ProfileData {
  photos: string[];
  bio: string;
  occupation: string;
  interests: string[];
  beardStyle?: string;
  beardPreferences?: string[];
  maxDistance: number;
  ageRange: [number, number];
  // Nouvelles préférences détaillées
  physicalPreferences?: {
    tattoos: number; // 0 = sans tatouage, 100 = avec tatouages
    smoking: number; // 0 = non-fumeur, 100 = fumeur
    diet: number; // 0 = végétarien, 100 = omnivore
    hairColor: number; // 0 = blonde, 50 = brune, 100 = rousse
    height: number; // 0 = petite, 100 = grande
    bodyHair: number; // 0 = rasée, 100 = poilue
    bodyType: number; // 0 = mince, 100 = athlétique/robuste
    style: number; // 0 = casual, 100 = élégant
  };
}

const BEARD_STYLES = [
  "Barbe complète",
  "Barbe hipster",
  "Barbe viking",
  "Barbe soignée",
  "Barbe distinguée",
  "Bouc",
  "Moustache",
];

const BEARD_PREFERENCES = [
  "Barbe complète",
  "Barbe hipster",
  "Barbe viking",
  "Barbe soignée",
  "Barbe distinguée",
  "Peu importe",
];

const INTERESTS_OPTIONS = [
  "Sport",
  "Voyage",
  "Cuisine",
  "Musique",
  "Cinéma",
  "Lecture",
  "Art",
  "Nature",
  "Gaming",
  "Photographie",
  "Danse",
  "Yoga",
  "Fitness",
  "Mode",
  "Technologie",
  "Gastronomie",
];

export function ProfileSetup({ signupData, onComplete, onBack }: ProfileSetupProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [profileData, setProfileData] = useState<ProfileData>({
    photos: [],
    bio: "",
    occupation: "",
    interests: [],
    beardStyle: signupData.gender === "man" ? undefined : undefined,
    beardPreferences: signupData.gender === "woman" ? [] : undefined,
    maxDistance: 50,
    ageRange: [25, 45],
    // Nouvelles préférences détaillées
    physicalPreferences: {
      tattoos: 50,
      smoking: 50,
      diet: 50,
      hairColor: 50,
      height: 50,
      bodyHair: 50,
      bodyType: 50,
      style: 50,
    },
  });
  const [errors, setErrors] = useState<Partial<Record<string, string>>>({});
  const [photoUrl, setPhotoUrl] = useState("");

  const isMan = signupData.gender === "man";
  const totalSteps = 5; // Changed from 4 to 5

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};

    if (profileData.photos.length === 0) {
      newErrors.photos = "Ajoutez au moins une photo";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};

    if (!profileData.bio || profileData.bio.length < 50) {
      newErrors.bio = "La bio doit contenir au moins 50 caractères";
    } else if (profileData.bio.length > 500) {
      newErrors.bio = "La bio ne peut pas dépasser 500 caractères";
    }

    if (!profileData.occupation || profileData.occupation.length < 2) {
      newErrors.occupation = "La profession est requise";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep3 = () => {
    const newErrors: Record<string, string> = {};

    if (profileData.interests.length < 3) {
      newErrors.interests = "Sélectionnez au moins 3 centres d'intérêt";
    }

    if (isMan && !profileData.beardStyle) {
      newErrors.beardStyle = "Sélectionnez votre style de barbe";
    }

    if (!isMan && (!profileData.beardPreferences || profileData.beardPreferences.length === 0)) {
      newErrors.beardPreferences = "Sélectionnez vos préférences de barbe";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    let isValid = false;

    if (currentStep === 1) {
      isValid = validateStep1();
    } else if (currentStep === 2) {
      isValid = validateStep2();
    } else if (currentStep === 3) {
      isValid = validateStep3();
    }

    if (isValid) {
      if (currentStep < totalSteps) {
        setCurrentStep(currentStep + 1);
      } else {
        onComplete(profileData);
      }
    }
  };

  const addPhoto = () => {
    if (photoUrl && profileData.photos.length < 6) {
      setProfileData((prev) => ({
        ...prev,
        photos: [...prev.photos, photoUrl],
      }));
      setPhotoUrl("");
    }
  };

  const removePhoto = (index: number) => {
    setProfileData((prev) => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index),
    }));
  };

  const toggleInterest = (interest: string) => {
    setProfileData((prev) => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter((i) => i !== interest)
        : [...prev.interests, interest],
    }));
  };

  const toggleBeardPreference = (preference: string) => {
    setProfileData((prev) => ({
      ...prev,
      beardPreferences: prev.beardPreferences?.includes(preference)
        ? prev.beardPreferences.filter((p) => p !== preference)
        : [...(prev.beardPreferences || []), preference],
    }));
  };

  // Default photos suggestions
  const getDefaultPhoto = () => {
    if (isMan) {
      return "https://images.unsplash.com/photo-1653071163478-177aa4035184?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFyZGVkJTIwbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzYyNDI1NjYxfDA&ixlib=rb-4.1.0&q=80&w=1080";
    }
    return "https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHByb2ZpbGUlMjBwaG90b3xlbnwxfHx8fDE3NjI0MjU2NjF8MA&ixlib=rb-4.1.0&q=80&w=1080";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50 flex flex-col">
      {/* Header */}
      <div className="p-6">
        <button
          onClick={currentStep === 1 ? onBack : () => setCurrentStep(currentStep - 1)}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
      </div>

      {/* Progress Bar */}
      <div className="px-6 mb-8">
        <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-pink-500 to-red-500 transition-all duration-300"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          />
        </div>
        <p className="mt-2 text-gray-600 text-center">
          Étape {currentStep} sur {totalSteps}
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center px-6 pb-6 overflow-y-auto">
        <div className="w-full max-w-md">
          {/* Step 1: Photos */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="mb-2">Ajoutez vos photos</h2>
                <p className="text-gray-600">
                  Montrez votre meilleur profil ! Ajoutez au moins une photo (6 maximum)
                </p>
              </div>

              {/* Photo Grid */}
              <div className="grid grid-cols-3 gap-3">
                {profileData.photos.map((photo, index) => (
                  <div key={index} className="relative aspect-square">
                    <ImageWithFallback
                      src={photo}
                      alt={`Photo ${index + 1}`}
                      className="w-full h-full object-cover rounded-xl"
                    />
                    <button
                      onClick={() => removePhoto(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center shadow-lg hover:bg-red-600 transition-colors"
                    >
                      <X className="w-4 h-4 text-white" />
                    </button>
                  </div>
                ))}

                {profileData.photos.length < 6 && (
                  <button
                    onClick={() => setPhotoUrl(getDefaultPhoto())}
                    className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center hover:border-pink-400 hover:bg-pink-50 transition-all"
                  >
                    <Plus className="w-8 h-8 text-gray-400" />
                    <span className="text-gray-500 mt-1">Ajouter</span>
                  </button>
                )}
              </div>

              {/* Add Photo URL */}
              {photoUrl && (
                <div className="space-y-2">
                  <Input
                    value={photoUrl}
                    onChange={(e) => setPhotoUrl(e.target.value)}
                    placeholder="URL de la photo"
                    className="h-12"
                  />
                  <Button
                    type="button"
                    onClick={addPhoto}
                    className="w-full"
                    variant="outline"
                  >
                    Confirmer l'ajout
                  </Button>
                </div>
              )}

              {errors.photos && <p className="text-red-500 text-center">{errors.photos}</p>}

              <p className="text-gray-500 text-center">
                Conseil : Utilisez des photos claires qui montrent bien votre visage{isMan ? " et votre barbe" : ""}
              </p>
            </div>
          )}

          {/* Step 2: Bio & Occupation */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="mb-2">Parlez de vous</h2>
                <p className="text-gray-600">
                  Rédigez une bio engageante qui reflète votre personnalité
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  placeholder={
                    isMan
                      ? "Ex: Passionné de nature et de café artisanal. Je cultive ma barbe depuis 5 ans et j'en suis très fier ! J'aime les longues randonnées et les soirées au coin du feu..."
                      : "Ex: Passionnée par l'authenticité et le naturel. J'adore les hommes qui assument leur virilité et leur style. Fan de cuisine, de voyages et de soirées entre amis..."
                  }
                  value={profileData.bio}
                  onChange={(e) =>
                    setProfileData((prev) => ({ ...prev, bio: e.target.value }))
                  }
                  className="min-h-[150px] resize-none"
                  maxLength={500}
                />
                <p className="text-gray-500 text-right">
                  {profileData.bio.length}/500 caractères
                </p>
                {errors.bio && <p className="text-red-500">{errors.bio}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="occupation">Profession</Label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="occupation"
                    type="text"
                    placeholder="Ex: Développeur web, Chef cuisinier, Architecte..."
                    value={profileData.occupation}
                    onChange={(e) =>
                      setProfileData((prev) => ({ ...prev, occupation: e.target.value }))
                    }
                    className="pl-10 h-12"
                  />
                </div>
                {errors.occupation && <p className="text-red-500">{errors.occupation}</p>}
              </div>
            </div>
          )}

          {/* Step 3: Interests & Style */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="mb-2">Vos centres d'intérêt</h2>
                <p className="text-gray-600">
                  Sélectionnez au moins 3 centres d'intérêt qui vous représentent
                </p>
              </div>

              {/* Interests */}
              <div className="space-y-2">
                <Label>Centres d'intérêt</Label>
                <div className="flex flex-wrap gap-2">
                  {INTERESTS_OPTIONS.map((interest) => (
                    <button
                      key={interest}
                      type="button"
                      onClick={() => toggleInterest(interest)}
                      className={`px-4 py-2 rounded-full transition-all ${
                        profileData.interests.includes(interest)
                          ? "bg-gradient-to-r from-pink-500 to-red-500 text-white shadow-md"
                          : "bg-white border-2 border-gray-200 text-gray-700 hover:border-pink-300"
                      }`}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
                <p className="text-gray-500">
                  {profileData.interests.length} sélectionné{profileData.interests.length > 1 ? "s" : ""}
                </p>
                {errors.interests && <p className="text-red-500">{errors.interests}</p>}
              </div>

              {/* Beard Style for Men */}
              {isMan && (
                <div className="space-y-2">
                  <Label>Votre style de barbe</Label>
                  <div className="flex flex-wrap gap-2">
                    {BEARD_STYLES.map((style) => (
                      <button
                        key={style}
                        type="button"
                        onClick={() =>
                          setProfileData((prev) => ({ ...prev, beardStyle: style }))
                        }
                        className={`px-4 py-2 rounded-full transition-all ${
                          profileData.beardStyle === style
                            ? "bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-md"
                            : "bg-white border-2 border-gray-200 text-gray-700 hover:border-purple-300"
                        }`}
                      >
                        {style}
                      </button>
                    ))}
                  </div>
                  {errors.beardStyle && <p className="text-red-500">{errors.beardStyle}</p>}
                </div>
              )}

              {/* Beard Preferences for Women */}
              {!isMan && (
                <div className="space-y-2">
                  <Label>Vos préférences de barbe</Label>
                  <div className="flex flex-wrap gap-2">
                    {BEARD_PREFERENCES.map((preference) => (
                      <button
                        key={preference}
                        type="button"
                        onClick={() => toggleBeardPreference(preference)}
                        className={`px-4 py-2 rounded-full transition-all ${
                          profileData.beardPreferences?.includes(preference)
                            ? "bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-md"
                            : "bg-white border-2 border-gray-200 text-gray-700 hover:border-purple-300"
                        }`}
                      >
                        {preference}
                      </button>
                    ))}
                  </div>
                  {errors.beardPreferences && (
                    <p className="text-red-500">{errors.beardPreferences}</p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Step 4: Detailed Physical Preferences */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="mb-2">Préférences physiques détaillées</h2>
                <p className="text-gray-600">
                  Ajustez chaque critère selon vos préférences (50% = aucune préférence)
                </p>
              </div>

              <div className="space-y-6">
                {/* Tattoos */}
                <PreferenceSlider
                  label="Tatouages"
                  icon="🎨"
                  value={profileData.physicalPreferences?.tattoos || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        tattoos: value,
                      },
                    }))
                  }
                  leftLabel="Sans tatouage"
                  rightLabel="Avec tatouages"
                />

                {/* Smoking */}
                <PreferenceSlider
                  label="Tabac"
                  icon="🚬"
                  value={profileData.physicalPreferences?.smoking || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        smoking: value,
                      },
                    }))
                  }
                  leftLabel="Non-fumeur"
                  rightLabel="Fumeur"
                />

                {/* Diet */}
                <PreferenceSlider
                  label="Régime alimentaire"
                  icon="🥗"
                  value={profileData.physicalPreferences?.diet || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        diet: value,
                      },
                    }))
                  }
                  leftLabel="Végétarien"
                  rightLabel="Omnivore"
                />

                {/* Hair Color */}
                <PreferenceSlider
                  label="Couleur de cheveux"
                  icon="💇"
                  value={profileData.physicalPreferences?.hairColor || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        hairColor: value,
                      },
                    }))
                  }
                  leftLabel="Blonde"
                  rightLabel="Brune / Rousse"
                />

                {/* Height */}
                <PreferenceSlider
                  label="Taille"
                  icon="📏"
                  value={profileData.physicalPreferences?.height || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        height: value,
                      },
                    }))
                  }
                  leftLabel="Petite"
                  rightLabel="Grande"
                />

                {/* Body Hair */}
                {isMan && (
                  <PreferenceSlider
                    label="Pilosité corporelle"
                    icon="✨"
                    value={profileData.physicalPreferences?.bodyHair || 50}
                    onChange={(value) =>
                      setProfileData((prev) => ({
                        ...prev,
                        physicalPreferences: {
                          ...prev.physicalPreferences!,
                          bodyHair: value,
                        },
                      }))
                    }
                    leftLabel="Rasée"
                    rightLabel="Poilue"
                  />
                )}

                {/* Body Type */}
                <PreferenceSlider
                  label="Morphologie"
                  icon="💪"
                  value={profileData.physicalPreferences?.bodyType || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        bodyType: value,
                      },
                    }))
                  }
                  leftLabel="Mince"
                  rightLabel="Athlétique / Robuste"
                />

                {/* Style */}
                <PreferenceSlider
                  label="Style vestimentaire"
                  icon="👔"
                  value={profileData.physicalPreferences?.style || 50}
                  onChange={(value) =>
                    setProfileData((prev) => ({
                      ...prev,
                      physicalPreferences: {
                        ...prev.physicalPreferences!,
                        style: value,
                      },
                    }))
                  }
                  leftLabel="Casual / Décontracté"
                  rightLabel="Élégant / Chic"
                />
              </div>

              <div className="bg-gradient-to-r from-pink-50 to-purple-50 border-2 border-pink-200 rounded-xl p-4">
                <p className="text-gray-700 text-center">
                  💡 <strong>Astuce :</strong> Plus vous êtes flexible (proches de 50%), plus vous aurez de matchs potentiels !
                </p>
              </div>
            </div>
          )}

          {/* Step 5: Basic Search Preferences (formerly Step 4) */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="mb-2">Préférences de recherche</h2>
                <p className="text-gray-600">
                  Définissez vos critères pour trouver les meilleurs matchs
                </p>
              </div>

              {/* Max Distance */}
              <div className="space-y-3">
                <Label>Distance maximale</Label>
                <div className="space-y-2">
                  <input
                    type="range"
                    min="5"
                    max="100"
                    step="5"
                    value={profileData.maxDistance}
                    onChange={(e) =>
                      setProfileData((prev) => ({
                        ...prev,
                        maxDistance: parseInt(e.target.value),
                      }))
                    }
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-pink-500"
                  />
                  <p className="text-center text-gray-700">
                    Jusqu'à {profileData.maxDistance} km
                  </p>
                </div>
              </div>

              {/* Age Range */}
              <div className="space-y-3">
                <Label>Tranche d'âge</Label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Input
                      type="number"
                      min="18"
                      max="99"
                      value={profileData.ageRange[0]}
                      onChange={(e) =>
                        setProfileData((prev) => ({
                          ...prev,
                          ageRange: [parseInt(e.target.value), prev.ageRange[1]],
                        }))
                      }
                      className="h-12 text-center"
                    />
                  </div>
                  <span className="text-gray-500">à</span>
                  <div className="flex-1">
                    <Input
                      type="number"
                      min="18"
                      max="99"
                      value={profileData.ageRange[1]}
                      onChange={(e) =>
                        setProfileData((prev) => ({
                          ...prev,
                          ageRange: [prev.ageRange[0], parseInt(e.target.value)],
                        }))
                      }
                      className="h-12 text-center"
                    />
                  </div>
                </div>
                <p className="text-center text-gray-600">
                  {profileData.ageRange[0]} - {profileData.ageRange[1]} ans
                </p>
              </div>

              <div className="bg-pink-50 border border-pink-200 rounded-xl p-4">
                <p className="text-gray-700 text-center">
                  Ces préférences peuvent être modifiées à tout moment dans les paramètres
                </p>
              </div>
            </div>
          )}

          {/* Navigation Button */}
          <div className="mt-8">
            <Button
              onClick={handleNextStep}
              className="w-full h-12 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white shadow-lg hover:shadow-xl transition-all"
            >
              {currentStep === totalSteps ? "Terminer" : "Continuer"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}