interface OneTwoLogoProps {
  size?: number;
  className?: string;
}

export function OneTwoLogo({ size = 40, className = "" }: OneTwoLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Outer circle */}
      <circle cx="50" cy="50" r="48" fill="white" stroke="#1a1a1a" strokeWidth="2" />
      
      {/* Yin Yang style split */}
      <path
        d="M 50 2 A 48 48 0 0 1 50 98 A 24 24 0 0 0 50 50 A 24 24 0 0 1 50 2 Z"
        fill="#1a1a1a"
      />
      <path
        d="M 50 2 A 48 48 0 0 0 50 98 A 24 24 0 0 1 50 50 A 24 24 0 0 0 50 2 Z"
        fill="url(#pinkGradient)"
      />
      
      {/* Small circles in each half */}
      <circle cx="50" cy="26" r="8" fill="url(#pinkGradient)" />
      <circle cx="50" cy="74" r="8" fill="#1a1a1a" />
      
      {/* First flame (top, white) */}
      <g transform="translate(50, 20)">
        <path
          d="M 0 0 C -2 -4 -3 -6 -2 -8 C -1 -10 1 -10 2 -8 C 3 -6 2 -4 0 0 C 1 -2 2 -3 2 -4 C 2 -5 1 -6 0 -6 C -1 -6 -2 -5 -2 -4 C -2 -3 -1 -2 0 0 Z"
          fill="white"
          stroke="#1a1a1a"
          strokeWidth="0.5"
        />
      </g>
      
      {/* Second flame (bottom, pink) */}
      <g transform="translate(50, 80)">
        <path
          d="M 0 0 C -2 4 -3 6 -2 8 C -1 10 1 10 2 8 C 3 6 2 4 0 0 C 1 2 2 3 2 4 C 2 5 1 6 0 6 C -1 6 -2 5 -2 4 C -2 3 -1 2 0 0 Z"
          fill="url(#pinkGradient)"
          stroke="white"
          strokeWidth="0.5"
        />
      </g>
      
      {/* Gradients */}
      <defs>
        <linearGradient id="pinkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ec4899" />
          <stop offset="100%" stopColor="#ef4444" />
        </linearGradient>
      </defs>
    </svg>
  );
}
