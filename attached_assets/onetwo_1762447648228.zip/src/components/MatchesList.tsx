import { MessageCircle } from "lucide-react";
import type { Profile } from "./SwipeCard";

interface MatchesListProps {
  matches: Profile[];
  onSelectMatch: (match: Profile) => void;
}

export function MatchesList({ matches, onSelectMatch }: MatchesListProps) {
  if (matches.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-200px)] text-center px-6">
        <div className="w-32 h-32 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full flex items-center justify-center mb-6">
          <MessageCircle className="w-16 h-16 text-pink-500" />
        </div>
        <h2 className="mb-2">Aucun match pour le moment</h2>
        <p className="text-gray-600">
          Commencez à swiper pour trouver des hommes barbus !
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="mb-6">Vos Matchs ({matches.length})</h2>
      
      <div className="grid gap-4">
        {matches.map((match) => (
          <button
            key={match.id}
            onClick={() => onSelectMatch(match)}
            className="flex items-center gap-4 p-4 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow border border-gray-100"
          >
            <div className="w-20 h-20 rounded-full overflow-hidden flex-shrink-0">
              <img
                src={match.imageUrl}
                alt={match.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="flex-1 text-left">
              <h4 className="mb-1">
                {match.name}, {match.age}
              </h4>
              <p className="text-gray-600">
                {match.beardStyle} • {match.distance} km
              </p>
              <p className="text-gray-500 line-clamp-1 mt-1">{match.bio}</p>
            </div>
            
            <MessageCircle className="w-6 h-6 text-pink-500 flex-shrink-0" />
          </button>
        ))}
      </div>
    </div>
  );
}
