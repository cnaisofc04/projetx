import { Heart, X } from "lucide-react";
import { motion } from "motion/react";

interface SwipeButtonsProps {
  onDislike: () => void;
  onLike: () => void;
}

export function SwipeButtons({ onDislike, onLike }: SwipeButtonsProps) {
  return (
    <div className="flex justify-center gap-6 mt-8">
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={onDislike}
        className="w-16 h-16 rounded-full bg-white shadow-xl flex items-center justify-center border-2 border-gray-200 hover:border-red-500 transition-colors"
      >
        <X className="w-8 h-8 text-red-500" />
      </motion.button>
      
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={onLike}
        className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-red-500 shadow-xl flex items-center justify-center hover:shadow-2xl transition-shadow"
      >
        <Heart className="w-8 h-8 text-white fill-white" />
      </motion.button>
    </div>
  );
}
