import { motion, useMotionValue, useTransform } from "motion/react";
import { Heart, X, Info } from "lucide-react";
import { useState } from "react";

export interface Profile {
  id: number;
  name: string;
  age: number;
  bio: string;
  distance: number;
  imageUrl: string;
  interests: string[];
  beardStyle: string;
}

interface SwipeCardProps {
  profile: Profile;
  onSwipe: (direction: "left" | "right") => void;
  onShowDetails: () => void;
}

export function SwipeCard({ profile, onSwipe, onShowDetails }: SwipeCardProps) {
  const [exitX, setExitX] = useState(0);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (_: any, info: any) => {
    if (Math.abs(info.offset.x) > 100) {
      setExitX(info.offset.x > 0 ? 300 : -300);
      onSwipe(info.offset.x > 0 ? "right" : "left");
    }
  };

  return (
    <motion.div
      className="absolute w-full h-[calc(100vh-200px)] max-w-md cursor-grab active:cursor-grabbing"
      style={{
        x,
        rotate,
        opacity,
      }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      animate={{ x: exitX }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className="relative h-full w-full rounded-3xl overflow-hidden shadow-2xl">
        <img
          src={profile.imageUrl}
          alt={profile.name}
          className="w-full h-full object-cover"
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        <button
          onClick={onShowDetails}
          className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm p-3 rounded-full shadow-lg hover:bg-white transition-colors"
        >
          <Info className="w-6 h-6 text-gray-800" />
        </button>

        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="flex items-end justify-between mb-4">
            <div>
              <h2 className="text-3xl mb-1">
                {profile.name}, {profile.age}
              </h2>
              <p className="text-sm opacity-90">
                À {profile.distance} km • {profile.beardStyle}
              </p>
            </div>
          </div>
          
          <p className="mb-4 line-clamp-2 opacity-90">{profile.bio}</p>
          
          <div className="flex flex-wrap gap-2">
            {profile.interests.slice(0, 3).map((interest, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full"
              >
                {interest}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
