import { Flame, MessageCircle, User } from "lucide-react";

interface NavigationProps {
  currentView: "swipe" | "matches" | "profile";
  onViewChange: (view: "swipe" | "matches" | "profile") => void;
  matchCount: number;
}

export function Navigation({ currentView, onViewChange, matchCount }: NavigationProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-40">
      <div className="flex justify-around items-center max-w-md mx-auto">
        <button
          onClick={() => onViewChange("swipe")}
          className={`flex-1 flex flex-col items-center gap-1 py-4 transition-colors ${
            currentView === "swipe"
              ? "text-pink-500"
              : "text-gray-400 hover:text-gray-600"
          }`}
        >
          <Flame className="w-7 h-7" />
          <span className="text-xs">Explorer</span>
        </button>

        <button
          onClick={() => onViewChange("matches")}
          className={`flex-1 flex flex-col items-center gap-1 py-4 transition-colors relative ${
            currentView === "matches"
              ? "text-pink-500"
              : "text-gray-400 hover:text-gray-600"
          }`}
        >
          <MessageCircle className="w-7 h-7" />
          {matchCount > 0 && (
            <span className="absolute top-2 right-1/2 translate-x-4 bg-pink-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
              {matchCount}
            </span>
          )}
          <span className="text-xs">Matchs</span>
        </button>

        <button
          onClick={() => onViewChange("profile")}
          className={`flex-1 flex flex-col items-center gap-1 py-4 transition-colors ${
            currentView === "profile"
              ? "text-pink-500"
              : "text-gray-400 hover:text-gray-600"
          }`}
        >
          <User className="w-7 h-7" />
          <span className="text-xs">Profil</span>
        </button>
      </div>
    </div>
  );
}
