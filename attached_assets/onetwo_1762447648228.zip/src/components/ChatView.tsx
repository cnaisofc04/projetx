import { useState } from "react";
import { ArrowLeft, Send } from "lucide-react";
import type { Profile } from "./SwipeCard";

interface Message {
  id: number;
  text: string;
  fromMe: boolean;
  timestamp: Date;
}

interface ChatViewProps {
  match: Profile;
  onBack: () => void;
}

export function ChatView({ match, onBack }: ChatViewProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: `Salut ! J'adore ta barbe ${match.beardStyle.toLowerCase()} ! 😍`,
      fromMe: true,
      timestamp: new Date(Date.now() - 3600000),
    },
  ]);
  const [newMessage, setNewMessage] = useState("");

  const handleSend = () => {
    if (!newMessage.trim()) return;

    setMessages([
      ...messages,
      {
        id: messages.length + 1,
        text: newMessage,
        fromMe: true,
        timestamp: new Date(),
      },
    ]);
    setNewMessage("");

    // Simulation de réponse
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          text: "Merci ! Ravi de faire ta connaissance 😊",
          fromMe: false,
          timestamp: new Date(),
        },
      ]);
    }, 2000);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <div className="bg-white border-b px-4 py-3 flex items-center gap-4">
        <button
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        <div className="w-12 h-12 rounded-full overflow-hidden">
          <img
            src={match.imageUrl}
            alt={match.name}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1">
          <h4>{match.name}</h4>
          <p className="text-gray-600">En ligne</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.fromMe ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                message.fromMe
                  ? "bg-gradient-to-r from-pink-500 to-red-500 text-white"
                  : "bg-white border border-gray-200"
              }`}
            >
              <p>{message.text}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border-t px-4 py-3 flex gap-3">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSend()}
          placeholder="Écrivez un message..."
          className="flex-1 px-4 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-500"
        />
        <button
          onClick={handleSend}
          disabled={!newMessage.trim()}
          className="w-12 h-12 bg-gradient-to-r from-pink-500 to-red-500 text-white rounded-full flex items-center justify-center hover:shadow-lg transition-shadow disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
