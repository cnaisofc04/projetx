import { Settings, Heart, Star, Camera } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function ProfileView() {
  return (
    <div className="h-screen overflow-y-auto pb-20 bg-gray-50">
      <div className="bg-gradient-to-br from-pink-500 to-purple-600 text-white p-6 pb-12">
        <div className="flex justify-between items-start mb-8">
          <h2>Mon Profil</h2>
          <button className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <Settings className="w-6 h-6" />
          </button>
        </div>

        <div className="flex flex-col items-center">
          <div className="relative mb-4">
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400"
                alt="Votre photo"
                className="w-full h-full object-cover"
              />
            </div>
            <button className="absolute bottom-0 right-0 bg-white text-pink-600 p-3 rounded-full shadow-lg">
              <Camera className="w-5 h-5" />
            </button>
          </div>
          
          <h3 className="mb-1">Sophie Martin</h3>
          <p className="text-white/80">28 ans • Paris</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 -mt-6">
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex justify-around">
            <div className="text-center">
              <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Heart className="w-6 h-6 text-pink-500" />
              </div>
              <p className="text-gray-600">Likes donnés</p>
              <p className="text-2xl">24</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Star className="w-6 h-6 text-purple-500" />
              </div>
              <p className="text-gray-600">Matchs</p>
              <p className="text-2xl">12</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h4 className="mb-4">Mes préférences</h4>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Style de barbe préféré</span>
              <span className="text-pink-600">Tous styles</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Distance maximale</span>
              <span className="text-pink-600">50 km</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Tranche d'âge</span>
              <span className="text-pink-600">25-40 ans</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h4 className="mb-4">À propos de moi</h4>
          <p className="text-gray-700">
            Passionnée par les hommes barbus et authentiques. J'adore la nature, 
            les bons restaurants et les conversations profondes. À la recherche 
            d'une connexion sincère avec un homme viril et barbu ! 🧔
          </p>
        </div>
      </div>
    </div>
  );
}
