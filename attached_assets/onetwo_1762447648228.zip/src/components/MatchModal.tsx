import { motion, AnimatePresence } from "motion/react";
import { Heart, MessageCircle, X } from "lucide-react";
import type { Profile } from "./SwipeCard";

interface MatchModalProps {
  profile: Profile | null;
  onClose: () => void;
  onSendMessage: () => void;
}

export function MatchModal({ profile, onClose, onSendMessage }: MatchModalProps) {
  if (!profile) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-gradient-to-br from-pink-500 via-red-500 to-purple-600 z-50 flex items-center justify-center p-4"
      >
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-white p-2 hover:bg-white/20 rounded-full transition-colors"
        >
          <X className="w-8 h-8" />
        </button>

        <div className="text-center text-white max-w-md">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            <Heart className="w-24 h-24 mx-auto mb-6 fill-white" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-4"
          >
            C'est un Match !
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mb-8 text-white/90"
          >
            Vous et {profile.name} vous êtes aimés mutuellement
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex gap-4 mb-8"
          >
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-xl mx-auto">
              <img
                src={profile.imageUrl}
                alt={profile.name}
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="space-y-3"
          >
            <button
              onClick={onSendMessage}
              className="w-full bg-white text-pink-600 px-8 py-4 rounded-full hover:bg-gray-100 transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Envoyer un message
            </button>
            <button
              onClick={onClose}
              className="w-full bg-white/20 text-white px-8 py-4 rounded-full hover:bg-white/30 transition-colors backdrop-blur-sm"
            >
              Continuer à swiper
            </button>
          </motion.div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
