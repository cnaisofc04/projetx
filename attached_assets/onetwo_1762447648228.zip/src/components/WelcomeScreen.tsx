import { Flame } from "lucide-react";
import { Button } from "./ui/button";
import { OneTwoLogo } from "./OneTwoLogo";

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50 flex flex-col items-center justify-center px-6">
      <div className="w-full max-w-md text-center">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <div className="transform hover:rotate-12 transition-transform">
            <OneTwoLogo size={96} />
          </div>
        </div>

        {/* Title */}
        <h1 className="mb-4 bg-gradient-to-r from-pink-600 to-red-600 bg-clip-text text-transparent">
          OneTwo
        </h1>
        <p className="mb-2 text-gray-700">
          L'application de rencontres pour les amoureuses de barbe
        </p>
        <p className="mb-12 text-gray-500">
          Connectez-vous avec des hommes barbus ou trouvez des femmes qui apprécient votre style naturel
        </p>

        {/* Features */}
        <div className="mb-12 space-y-4 text-left">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center flex-shrink-0">
              <span className="text-pink-600">❤️</span>
            </div>
            <div>
              <h3 className="text-gray-900 mb-1">Matchs authentiques</h3>
              <p className="text-gray-600">
                Rencontrez des personnes qui partagent votre passion pour les barbes
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
              <span className="text-purple-600">💬</span>
            </div>
            <div>
              <h3 className="text-gray-900 mb-1">Chat en temps réel</h3>
              <p className="text-gray-600">
                Discutez instantanément avec vos matchs
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
              <span className="text-red-600">🔥</span>
            </div>
            <div>
              <h3 className="text-gray-900 mb-1">Profils détaillés</h3>
              <p className="text-gray-600">
                Découvrez des profils complets avec styles de barbe et centres d'intérêt
              </p>
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <Button
          onClick={onGetStarted}
          className="w-full h-14 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white shadow-lg hover:shadow-xl transition-all"
        >
          Commencer l'aventure
        </Button>

        <p className="mt-6 text-gray-400">
          En continuant, vous acceptez nos conditions d'utilisation
        </p>
      </div>
    </div>
  );
}