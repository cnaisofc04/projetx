import { X, MapPin, Briefcase, GraduationCap } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import type { Profile } from "./SwipeCard";

interface ProfileModalProps {
  profile: Profile | null;
  onClose: () => void;
}

export function ProfileModal({ profile, onClose }: ProfileModalProps) {
  if (!profile) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 30 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md max-h-[85vh] overflow-y-auto"
        >
          <div className="sticky top-0 bg-white z-10 p-4 border-b flex justify-between items-center">
            <h3>Profil de {profile.name}</h3>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="relative h-96">
            <img
              src={profile.imageUrl}
              alt={profile.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-6 space-y-6">
            <div>
              <h2 className="mb-2">
                {profile.name}, {profile.age}
              </h2>
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>À {profile.distance} km</span>
              </div>
            </div>

            <div>
              <h4 className="mb-3">À propos</h4>
              <p className="text-gray-700">{profile.bio}</p>
            </div>

            <div>
              <h4 className="mb-3">Style de barbe</h4>
              <div className="inline-block px-4 py-2 bg-gradient-to-r from-pink-50 to-purple-50 rounded-full">
                {profile.beardStyle}
              </div>
            </div>

            <div>
              <h4 className="mb-3">Centres d'intérêt</h4>
              <div className="flex flex-wrap gap-2">
                {profile.interests.map((interest, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-gray-100 rounded-full"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
