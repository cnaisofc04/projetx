import { Label } from "./ui/label";

interface PreferenceSliderProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  leftLabel: string;
  rightLabel: string;
  icon?: string;
}

export function PreferenceSlider({
  label,
  value,
  onChange,
  leftLabel,
  rightLabel,
  icon,
}: PreferenceSliderProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        {icon && <span className="text-xl">{icon}</span>}
        <Label>{label}</Label>
      </div>
      
      <div className="space-y-2">
        {/* Labels */}
        <div className="flex items-center justify-between text-gray-600">
          <span className={value <= 50 ? "text-pink-600" : ""}>{leftLabel}</span>
          <span className={value >= 50 ? "text-pink-600" : ""}>{rightLabel}</span>
        </div>
        
        {/* Slider */}
        <div className="relative">
          <input
            type="range"
            min="0"
            max="100"
            value={value}
            onChange={(e) => onChange(parseInt(e.target.value))}
            className="w-full h-3 bg-gradient-to-r from-pink-200 via-gray-200 to-purple-200 rounded-full appearance-none cursor-pointer slider-thumb"
            style={{
              background: `linear-gradient(to right, #fbcfe8 0%, #fbcfe8 ${value}%, #e5e7eb ${value}%, #e5e7eb 100%)`,
            }}
          />
          <div
            className="absolute top-1/2 -translate-y-1/2 w-5 h-5 bg-gradient-to-br from-pink-500 to-red-500 rounded-full shadow-lg pointer-events-none border-2 border-white"
            style={{ left: `calc(${value}% - 10px)` }}
          />
        </div>
        
        {/* Percentage indicator */}
        <div className="text-center">
          <span className="inline-block px-3 py-1 bg-gradient-to-r from-pink-500 to-red-500 text-white rounded-full">
            {value}%
          </span>
        </div>
        
        {/* Description */}
        <p className="text-gray-500 text-center">
          {value === 0 && `Uniquement ${leftLabel.toLowerCase()}`}
          {value > 0 && value < 25 && `Forte préférence ${leftLabel.toLowerCase()}`}
          {value >= 25 && value < 50 && `Préférence ${leftLabel.toLowerCase()}`}
          {value === 50 && "Aucune préférence"}
          {value > 50 && value <= 75 && `Préférence ${rightLabel.toLowerCase()}`}
          {value > 75 && value < 100 && `Forte préférence ${rightLabel.toLowerCase()}`}
          {value === 100 && `Uniquement ${rightLabel.toLowerCase()}`}
        </p>
      </div>
    </div>
  );
}
