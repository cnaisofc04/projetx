import { useState } from "react";
import { WelcomeScreen } from "./WelcomeScreen";
import { AuthChoice } from "./AuthChoice";
import { GenderChoice } from "./GenderChoice";
import { SignupForm, type SignupData } from "./SignupForm";
import { LoginForm } from "./LoginForm";
import { ProfileSetup, type ProfileData } from "./ProfileSetup";

type OnboardingStep =
  | "welcome"
  | "auth-choice"
  | "gender-choice"
  | "signup"
  | "login"
  | "profile-setup";

interface OnboardingFlowProps {
  onComplete: (userData: UserData) => void;
}

export interface UserData {
  signupData: SignupData;
  profileData: ProfileData;
}

export function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>("welcome");
  const [selectedGender, setSelectedGender] = useState<"man" | "woman">("woman");
  const [signupData, setSignupData] = useState<SignupData | null>(null);

  const handleGetStarted = () => {
    setCurrentStep("auth-choice");
  };

  const handleSignup = () => {
    setCurrentStep("gender-choice");
  };

  const handleLogin = () => {
    setCurrentStep("login");
  };

  const handleGenderSelect = (gender: "man" | "woman") => {
    setSelectedGender(gender);
    setCurrentStep("signup");
  };

  const handleSignupComplete = (data: SignupData) => {
    setSignupData(data);
    setCurrentStep("profile-setup");
  };

  const handleLoginComplete = (email: string, password: string) => {
    // Pour la version mockée, on simule une connexion réussie
    // Dans une vraie app avec Supabase, on vérifierait les credentials ici
    console.log("Login attempt:", email, password);
    
    // Simuler un utilisateur existant avec des données par défaut
    const mockSignupData: SignupData = {
      email,
      password,
      firstName: "Utilisateur",
      lastName: "Existant",
      birthDate: "1990-01-01",
      city: "Paris",
      gender: "woman",
    };

    const mockProfileData: ProfileData = {
      photos: ["https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHByb2ZpbGUlMjBwaG90b3xlbnwxfHx8fDE3NjI0MjU2NjF8MA&ixlib=rb-4.1.0&q=80&w=1080"],
      bio: "Passionnée par l'authenticité et les hommes qui assument leur style naturel.",
      occupation: "Designer",
      interests: ["Art", "Voyage", "Cuisine"],
      beardPreferences: ["Barbe complète", "Barbe hipster"],
      maxDistance: 50,
      ageRange: [25, 45],
    };

    onComplete({
      signupData: mockSignupData,
      profileData: mockProfileData,
    });
  };

  const handleProfileSetupComplete = (profileData: ProfileData) => {
    if (signupData) {
      onComplete({
        signupData,
        profileData,
      });
    }
  };

  const handleBackToWelcome = () => {
    setCurrentStep("welcome");
  };

  const handleBackToAuthChoice = () => {
    setCurrentStep("auth-choice");
  };

  const handleBackToGenderChoice = () => {
    setCurrentStep("gender-choice");
  };

  const handleBackToSignup = () => {
    setCurrentStep("signup");
  };

  return (
    <>
      {currentStep === "welcome" && <WelcomeScreen onGetStarted={handleGetStarted} />}

      {currentStep === "auth-choice" && (
        <AuthChoice
          onSignup={handleSignup}
          onLogin={handleLogin}
          onBack={handleBackToWelcome}
        />
      )}

      {currentStep === "gender-choice" && (
        <GenderChoice onSelect={handleGenderSelect} onBack={handleBackToAuthChoice} />
      )}

      {currentStep === "signup" && (
        <SignupForm
          gender={selectedGender}
          onSignup={handleSignupComplete}
          onBack={handleBackToGenderChoice}
        />
      )}

      {currentStep === "login" && (
        <LoginForm onLogin={handleLoginComplete} onBack={handleBackToAuthChoice} />
      )}

      {currentStep === "profile-setup" && signupData && (
        <ProfileSetup
          signupData={signupData}
          onComplete={handleProfileSetupComplete}
          onBack={handleBackToSignup}
        />
      )}
    </>
  );
}
