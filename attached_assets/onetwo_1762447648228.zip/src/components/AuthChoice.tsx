import { Flame, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { OneTwoLogo } from "./OneTwoLogo";

interface AuthChoiceProps {
  onSignup: () => void;
  onLogin: () => void;
  onBack: () => void;
}

export function AuthChoice({ onSignup, onLogin, onBack }: AuthChoiceProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50 flex flex-col">
      {/* Header */}
      <div className="p-6">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 -mt-16">
        <div className="w-full max-w-md text-center">
          {/* Logo */}
          <div className="mb-8 flex justify-center">
            <OneTwoLogo size={80} />
          </div>

          <h1 className="mb-3 bg-gradient-to-r from-pink-600 to-red-600 bg-clip-text text-transparent">
            Rejoignez OneTwo
          </h1>
          <p className="mb-12 text-gray-600">
            Créez votre compte ou connectez-vous pour commencer
          </p>

          <div className="space-y-4">
            <Button
              onClick={onSignup}
              className="w-full h-14 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white shadow-lg hover:shadow-xl transition-all"
            >
              Créer un compte
            </Button>

            <Button
              onClick={onLogin}
              variant="outline"
              className="w-full h-14 border-2 border-pink-200 hover:border-pink-300 hover:bg-pink-50 transition-all"
            >
              Se connecter
            </Button>
          </div>

          <p className="mt-8 text-gray-500">
            Nouveau sur OneTwo ? Créez un compte pour découvrir des profils correspondant à vos préférences
          </p>
        </div>
      </div>
    </div>
  );
}