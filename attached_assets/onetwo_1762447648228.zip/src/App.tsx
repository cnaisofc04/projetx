import { useState } from "react";
import { SwipeCard, type Profile } from "./components/SwipeCard";
import { SwipeButtons } from "./components/SwipeButtons";
import { ProfileModal } from "./components/ProfileModal";
import { MatchModal } from "./components/MatchModal";
import { MatchesList } from "./components/MatchesList";
import { ChatView } from "./components/ChatView";
import { ProfileView } from "./components/ProfileView";
import { Navigation } from "./components/Navigation";
import { OnboardingFlow, type UserData } from "./components/OnboardingFlow";
import { OneTwoLogo } from "./components/OneTwoLogo";
import { LogOut } from "lucide-react";

// Données mockées de profils d'hommes barbus
const mockProfiles: Profile[] = [
  {
    id: 1,
    name: "Alexandre",
    age: 32,
    bio: "Barbe complète depuis 5 ans, passionné de bûcheronnage et de café artisanal. J'aime les longues randonnées en forêt et les soirées au coin du feu.",
    distance: 3,
    imageUrl: "https://images.unsplash.com/photo-1649107742568-de2b3b442b9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFyZGVkJTIwbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzYyMjgwMTQ5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    interests: ["Bûcheronnage", "Café", "Randonnée", "Nature", "Photographie"],
    beardStyle: "Barbe complète",
  },
  {
    id: 2,
    name: "Thomas",
    age: 29,
    bio: "Hipster assumé avec une belle barbe taillée. Fan de vinyle, de bière artisanale et de food trucks. Toujours partant pour découvrir de nouveaux endroits !",
    distance: 5,
    imageUrl: "https://images.unsplash.com/photo-1550090597-8415c4411f52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYWlyeSUyMGJlYXJkZWQlMjBtYW58ZW58MXx8fHwxNzYyMzYyNzgxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    interests: ["Musique", "Bière artisanale", "Street food", "Art", "Voyages"],
    beardStyle: "Barbe hipster",
  },
  {
    id: 3,
    name: "Lucas",
    age: 35,
    bio: "Barbe de viking, cœur de guerrier. Coach sportif et amoureux de la nature. Je recherche une femme qui apprécie les hommes authentiques et virils.",
    distance: 7,
    imageUrl: "https://images.unsplash.com/photo-1580538600836-4bffd68cc222?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXBzdGVyJTIwYmVhcmQlMjBtYW58ZW58MXx8fHwxNzYyMzYyNzgxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    interests: ["Fitness", "CrossFit", "Escalade", "Nutrition", "Méditation"],
    beardStyle: "Barbe viking",
  },
  {
    id: 4,
    name: "Maxime",
    age: 31,
    bio: "Barbu et fier de l'être ! Développeur le jour, musicien la nuit. J'aime les conversations intellectuelles et les sorties culturelles.",
    distance: 4,
    imageUrl: "https://images.unsplash.com/photo-1517832606299-7ae9b720a186?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXNjdWxpbmUlMjBiZWFyZGVkJTIwbWFufGVufDF8fHx8MTc2MjM2Mjc4Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    interests: ["Tech", "Musique", "Cinéma", "Gaming", "Philosophie"],
    beardStyle: "Barbe soignée",
  },
  {
    id: 5,
    name: "Antoine",
    age: 38,
    bio: "Barbe grisonnante et caractère bien trempé. Chef cuisinier passionné, j'aime faire plaisir aux autres avec mes plats. Romantique dans l'âme.",
    distance: 2,
    imageUrl: "https://images.unsplash.com/photo-1644437687093-8a01d1721fae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydWdnZWQlMjBtYW4lMjBiZWFyZHxlbnwxfHx8fDE3NjIzNjI3ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    interests: ["Cuisine", "Vin", "Gastronomie", "Voyage", "Lecture"],
    beardStyle: "Barbe distinguée",
  },
];

export default function App() {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userData, setUserData] = useState<UserData | null>(null);
  
  const [currentView, setCurrentView] = useState<"swipe" | "matches" | "profile">("swipe");
  const [profiles, setProfiles] = useState(mockProfiles);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [matches, setMatches] = useState<Profile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [matchedProfile, setMatchedProfile] = useState<Profile | null>(null);
  const [chatMatch, setChatMatch] = useState<Profile | null>(null);

  // Handle onboarding completion
  const handleOnboardingComplete = (data: UserData) => {
    setUserData(data);
    setIsAuthenticated(true);
    // In production, this would save to Supabase
    localStorage.setItem("onetwo_user", JSON.stringify(data));
  };

  // Handle logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserData(null);
    localStorage.removeItem("onetwo_user");
    // Reset app state
    setCurrentView("swipe");
    setProfiles(mockProfiles);
    setCurrentIndex(0);
    setMatches([]);
    setSelectedProfile(null);
    setMatchedProfile(null);
    setChatMatch(null);
  };

  // Show onboarding if not authenticated
  if (!isAuthenticated) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  const handleSwipe = (direction: "left" | "right") => {
    if (direction === "right") {
      // 50% de chance de match
      const isMatch = Math.random() > 0.5;
      if (isMatch) {
        const newMatch = profiles[currentIndex];
        setMatches([...matches, newMatch]);
        setMatchedProfile(newMatch);
      }
    }
    
    setTimeout(() => {
      setCurrentIndex((prev) => prev + 1);
    }, 300);
  };

  const handleButtonSwipe = (direction: "left" | "right") => {
    handleSwipe(direction);
  };

  const handleSelectMatch = (match: Profile) => {
    setChatMatch(match);
  };

  const handleSendMessage = () => {
    if (matchedProfile) {
      setChatMatch(matchedProfile);
      setMatchedProfile(null);
      setCurrentView("matches");
    }
  };

  if (chatMatch) {
    return <ChatView match={chatMatch} onBack={() => setChatMatch(null)} />;
  }

  return (
    <div className="h-screen bg-gray-50 overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <OneTwoLogo size={40} />
          <h1 className="bg-gradient-to-r from-pink-500 to-red-500 bg-clip-text text-transparent">
            OneTwo
          </h1>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
          title="Se déconnecter"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="h-[calc(100vh-140px)] overflow-y-auto">
        {currentView === "swipe" && (
          <div className="flex flex-col items-center justify-center h-full px-4">
            {currentIndex < profiles.length ? (
              <>
                <div className="relative w-full max-w-md h-[calc(100vh-280px)]">
                  {profiles
                    .slice(currentIndex, currentIndex + 2)
                    .reverse()
                    .map((profile, index) => (
                      <SwipeCard
                        key={profile.id}
                        profile={profile}
                        onSwipe={handleSwipe}
                        onShowDetails={() => setSelectedProfile(profile)}
                      />
                    ))}
                </div>
                
                <SwipeButtons
                  onDislike={() => handleButtonSwipe("left")}
                  onLike={() => handleButtonSwipe("right")}
                />
              </>
            ) : (
              <div className="text-center px-6">
                <div className="w-32 h-32 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Flame className="w-16 h-16 text-pink-500" />
                </div>
                <h2 className="mb-2">Plus de profils disponibles</h2>
                <p className="text-gray-600 mb-6">
                  Revenez plus tard pour découvrir de nouveaux hommes barbus !
                </p>
                <button
                  onClick={() => {
                    setProfiles(mockProfiles);
                    setCurrentIndex(0);
                  }}
                  className="bg-gradient-to-r from-pink-500 to-red-500 text-white px-8 py-3 rounded-full hover:shadow-lg transition-shadow"
                >
                  Recommencer
                </button>
              </div>
            )}
          </div>
        )}

        {currentView === "matches" && (
          <MatchesList matches={matches} onSelectMatch={handleSelectMatch} />
        )}

        {currentView === "profile" && <ProfileView />}
      </div>

      {/* Navigation */}
      <Navigation
        currentView={currentView}
        onViewChange={setCurrentView}
        matchCount={matches.length}
      />

      {/* Modals */}
      {selectedProfile && (
        <ProfileModal
          profile={selectedProfile}
          onClose={() => setSelectedProfile(null)}
        />
      )}

      {matchedProfile && (
        <MatchModal
          profile={matchedProfile}
          onClose={() => setMatchedProfile(null)}
          onSendMessage={handleSendMessage}
        />
      )}
    </div>
  );
}